"""PBIR visual templates."""
